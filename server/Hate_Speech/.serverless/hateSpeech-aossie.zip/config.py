DEBUG = True # Turns on debugging features in Flask
SECRET_KEY = 'b6256da821325782f664b0af78bba330'
CORS_HEADERS = 'Content-Type'
