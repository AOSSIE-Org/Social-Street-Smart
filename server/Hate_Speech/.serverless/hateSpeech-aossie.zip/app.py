from hate_speech_api import app

app = app

