DEBUG = False # Turns on debugging features in Flask
SECRET_KEY = 'b6256da821325782f664b0af78bba333'
CORS_HEADERS = 'Content-Type'
