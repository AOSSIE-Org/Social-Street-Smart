from clickbait_api import app

app=app
